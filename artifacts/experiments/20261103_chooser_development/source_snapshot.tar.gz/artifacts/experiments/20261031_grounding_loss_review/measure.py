"""Counterfactual grounding objectives at identical saved weights; no parameter updates."""
import os
os.environ.setdefault('JAX_PLATFORMS','cpu')
import hashlib
import json
from pathlib import Path
import numpy as np
import torch
from saccade import model as M, train as TR
from saccade.eval import s1 as S

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
DEV=torch.device('cuda')
WORLDS={'base':ROOT/'artifacts/saccade_m0/p1_world1/ckpt_10.pt',
        'p1f':HERE.parent/'20261030_p1_guided/run/ckpt_10.pt'}


def single_labels(L,e,t):
    so=np.r_[0,np.cumsum(L['ep_T']+1)];ao=np.r_[0,np.cumsum(L['ep_T'])]
    out={k:v[e:e+1] if k.startswith('ep_') else v[so[e]:so[e]+t+1] if k.startswith('s_')
         else v[ao[e]:ao[e]+t] for k,v in L.items()}
    out['ep_T']=np.array([t],np.int32)
    return out


def summarize(acc,n):
    out={}
    for key,a in acc.items():
        mean=a['sum']/n
        common=float(mean.square().sum())
        mean_sq=a['norm2']/n
        out[key]={'mean_draw_norm':a['norm']/n,'rms_draw_norm':mean_sq**.5,
                  'mean_gradient_norm':common**.5,
                  'noise_variance_fraction':max(0.,1-common/max(mean_sq,1e-30))}
    return out


def main():
    torch.set_num_threads(4)
    scenes=json.loads((HERE/'scenes.json').read_text())
    frames=np.load(HERE/'renders.npz')['frames']
    L=dict(np.load(ROOT/'artifacts/eda/s0/s0_dev_labels.npz'))
    res={'worlds':{},'scope':'direct current-frame encoder gradients; fixed real-prefix belief; raw, unweighted gradients'}
    for world,path in WORLDS.items():
        ck=torch.load(path,weights_only=False,map_location='cpu');cfg=ck['cfg']
        model=M.M0(cfg).to(DEV);model.load_state_dict(ck['model']);model.eval();del ck
        named=list(model.perception.named_parameters());params=[p for _,p in named]
        module=lambda k:'fovea' if k.startswith('fovea.') else 'lighting' if k.startswith('light.') else 'periphery'
        groups={g:[i for i,(name,_) in enumerate(named) if module(name)==g] for g in ('periphery','fovea','lighting')}
        res['worlds'][world]={'checkpoint_sha256':TR.file_sha256(path),'scenes':[]}
        for si,row in enumerate(scenes['rows']):
            encoded=S.encode(model,single_labels(L,row['episode'],row['t']),cfg)[0]
            bp=encoded['bp'][-1].float()[None].to(DEV)
            del encoded
            for li,light in enumerate(scenes['light']):
                acc,aux,tokens={}, {}, {'p':[],'g':[],'v':[]}
                for ni in range(frames.shape[2]):
                    image=torch.as_tensor(frames[si,li,ni][None],device=DEV)
                    fix=torch.tensor([[5,4]],device=DEV);cells=M.window(fix)
                    with TR.autocast(DEV,cfg):
                        Pc=model.perception(image,fix)
                        routes={'tsp':model.pixels(model.tsp.predict(bp,Pc.p,Pc.v,cells),Pc.v,cells),
                                'rec':model.pixels(model.tsp.reconstruct(Pc.g,Pc.v,cells),Pc.v,cells)}
                    for k,z in zip(('p','g','v'),Pc.parts()):tokens[k].append(z.detach().float().cpu())
                    pixels=M.cell_pixels(M.crop(image,fix));y=pixels.float()/127.5-1
                    for route,(mu,ls) in routes.items():
                        mu,ls=mu.float(),ls.float()
                        losses={'nll_full':M.pixel_nll(mu,ls,pixels).mean(),
                                'nll_mean':M.pixel_nll(mu,ls.detach(),pixels).mean(),
                                'mse':(mu-y).square().mean()}
                        aux.setdefault(route,{'mae':[],'scale':[],'output_mean_gradient':{k:[] for k in losses}})
                        aux[route]['mae'].append(float((mu-y).detach().abs().mean()))
                        aux[route]['scale'].append(float(ls.detach().clamp(min=-7).exp().mean()))
                        for form,loss in losses.items():
                            output=torch.autograd.grad(loss,mu,retain_graph=True)[0]
                            aux[route]['output_mean_gradient'][form].append(float(output.abs().mean())*mu.numel())
                            grads=torch.autograd.grad(loss,params,allow_unused=True,retain_graph=True)
                            for g,indices in groups.items():
                                vec=torch.cat([(torch.zeros_like(params[i]) if grads[i] is None else grads[i])
                                               .detach().float().flatten().cpu() for i in indices])
                                key=f'{route}/{form}/{g}'
                                if key not in acc:acc[key]={'sum':torch.zeros_like(vec),'norm2':0.,'norm':0.}
                                sq=float(vec.square().sum());acc[key]['sum']+=vec;acc[key]['norm2']+=sq;acc[key]['norm']+=sq**.5
                    del Pc,routes,losses,loss,grads,mu,ls,output
                token_stats={}
                for k,v in tokens.items():
                    z=torch.cat(v)
                    if k=='p':z=z[:,:63]
                    token_stats[k]={'mean_noise_variance_per_scalar':float(z.var(0,unbiased=False).mean()),
                                    'mean_second_moment':float(z.square().mean())}
                out={'scene':si,'episode':row['episode'],'t':row['t'],'light':light,
                     'token_stats':token_stats,'gradient':summarize(acc,frames.shape[2]),
                     'pixel':{r:{'mae_normalized':float(np.mean(v['mae'])),'mean_scale':float(np.mean(v['scale'])),
                                'mean_abs_output_gradient':{k:float(np.mean(a)) for k,a in v['output_mean_gradient'].items()}}
                              for r,v in aux.items()}}
                res['worlds'][world]['scenes'].append(out)
                print(world,'scene',si,'light',light,'token noise',token_stats['p']['mean_noise_variance_per_scalar'],flush=True)
                print('  tsp mean-gradient',out['pixel']['tsp']['mean_abs_output_gradient'],flush=True)
                (HERE/'results.json').write_text(json.dumps(res,indent=2))
        del model;torch.cuda.empty_cache()
    res['sources_sha256']={str(p.relative_to(ROOT)):TR.file_sha256(p) for p in [Path(__file__),HERE/'PLAN.md',HERE/'render_noise.py',
            ROOT/'saccade/model.py',ROOT/'saccade/train.py',ROOT/'saccade/eval/s1.py']}
    (HERE/'results.json').write_text(json.dumps(res,indent=2))
    print('done',flush=True)


if __name__=='__main__':main()
