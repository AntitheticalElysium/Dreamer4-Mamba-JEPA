"""Read-only, fixed-weight sampler factorial. See PLAN.md before interpreting results."""
import os
os.environ.setdefault('JAX_PLATFORMS', 'cpu')
os.environ.setdefault('OMP_NUM_THREADS', '4')
import argparse, importlib, json, math, time
from pathlib import Path
import numpy as np
import torch
from saccade import model as M, train as TR
from saccade.eval import s1 as S, gates as G

HERE = Path(__file__).resolve().parent
A = importlib.import_module('artifacts.experiments.20261031_learned_fixation_sweep.decompose')
CAT = importlib.import_module('artifacts.experiments.20261029_generation_diagnosis.catalogue')
EST = importlib.import_module('artifacts.experiments.20261031_grounding_loss_review.followup.analyze').estimate
DEV = torch.device('cuda')
ALGS = {f'euler_{n}_churn_{c}': (n, False, float(c), 0., float('inf'), 1., 5.)
        for n in (3, 8, 32) for c in (0, 1)}
ALGS['heun_32_churn_0'] = (32, True, 0., 0., float('inf'), 1., 5.)


def sample(den, shapes, prev_action, memory, fix, cache, alg, cfg, gen):
    # Keep the native GPU float64 schedule AND Euler arithmetic ordering exactly.
    # The earlier CPU-schedule helper differs under bf16 despite algebraic equivalence.
    n, heun, churn, tmin, tmax, s_noise, smax = alg
    e, s = cfg['edm'], cfg['edm']['sampler']
    i = torch.arange(n, device=memory.device, dtype=torch.float64)
    sig = (smax ** (1 / s['rho']) + i / (n - 1) * (s['sigma_min'] ** (1 / s['rho']) - smax ** (1 / s['rho']))) ** s['rho']
    sig = torch.cat([sig, sig.new_zeros(1)]).tolist()
    B = memory.shape[0]
    randn = lambda shape: torch.randn(shape, device=memory.device, generator=gen)
    x = tuple(sig[0] * randn((B, 1, *shape)) for shape in shapes)
    def denoise(x, sigma):
        return M.denoised(den, x, torch.full((B, 1), sigma, device=memory.device), prev_action,
                          memory, fix, cache, cfg['perception']['periphery']['tanh_clamp'], e['sigma_data'])[0]
    for k in range(n):
        gamma = min(churn / n, math.sqrt(2) - 1) if tmin <= sig[k] <= tmax else 0.
        hat = sig[k] * (1 + gamma)
        if gamma > 0:
            x = tuple(t + math.sqrt(hat ** 2 - sig[k] ** 2) * s_noise * randn(t.shape) for t in x)
        D = denoise(x, hat)
        new = tuple(t + (sig[k + 1] - hat) * (t - d) / hat for t, d in zip(x, D))
        if heun and sig[k + 1] > 0:
            D2 = denoise(new, sig[k + 1])
            new = tuple(t + (sig[k + 1] - hat) * ((t - d) / hat + (u - d2) / sig[k + 1]) / 2
                        for t, d, u, d2 in zip(x, D, new, D2))
        x = new
    return tuple(t[:, 0] for t in x)


def stats(x, ep):
    return EST(np.asarray(x, float), ep)


@torch.no_grad()
def evaluate(model, cfg, reader, enc, L, panels, grids):
    result, checks = {}, []
    so = np.r_[0, np.cumsum(L['ep_T'] + 1)]
    for panel, rows in panels.items():
        raw = {k: [] for k in ('ep', 'row', 'real_shift', 'valid', 'real_kind', 'truth_kind')}
        for alg in ALGS:
            raw[alg] = {'shift': [], 'kind': []}
        for start in range(0, len(rows), 32):
            batch = rows[start:start + 32]
            idx = [i for i in range(len(batch)) for _ in range(2)]
            take = lambda key, dt: torch.stack([enc[batch[i][0]][key][batch[i][1] + dt] for i in idx]).to(DEV)
            B = len(idx)
            ep = np.array([batch[i][0] for i in idx])
            raw['ep'].extend(ep.tolist())
            raw['row'].extend([start + i for i in idx])
            real = take('p', 0).float()
            if panel == 'move':
                base, weight, valid = CAT.functional('move', batch, enc, L, so, {}, {})
                base, weight = base[idx].to(DEV), weight[idx].to(DEV)
                f = lambda p: ((p.float() - base) * weight).sum((-1, -2)).cpu().tolist()
                raw['real_shift'].extend(f(real))
                raw['valid'].extend(valid[idx].tolist())
            else:
                f = lambda p: []
                raw['real_kind'].extend(kind_grid(reader, real, take('v', 0)).tolist())
                raw['truth_kind'].extend([grids[batch[i][0]][batch[i][1]].reshape(63)[S.KEEP[:63]].tolist() for i in idx])
            cache = model.denoiser.new_cache()
            with TR.autocast(DEV, cfg):
                cg = torch.Generator(device=DEV).manual_seed(610371 + start + 1000 * (panel == 'move'))
                for dt in range(-8, 0):
                    cache = M.context_pass(model.denoiser, tuple(take(k, dt).float()[:, None] for k in ('p','g','v')),
                        take('prev_action', dt)[:, None], model.belief.memory(take('bp', dt).float())[:, None],
                        take('fix', dt)[:, None], cache, cfg, cg)
                pa = take('prev_action', 0)[:, None]
                mem = model.belief.memory(take('bp', 0).float())[:, None]
                fix = take('fix', 0)[:, None]
                shapes = [tuple(take(k, 0).shape[1:]) for k in ('p','g','v')]
                seed = 610372 + start + 1000 * (panel == 'move')
                for name, alg in ALGS.items():
                    gen = torch.Generator(device=DEV).manual_seed(seed)
                    out = sample(model.denoiser, shapes, pa, mem, fix, cache, alg, cfg, gen)
                    if name == 'euler_3_churn_1' and start == 0:
                        native = M.sample(model.denoiser, shapes, pa, mem, fix, cache, cfg,
                            torch.Generator(device=DEV).manual_seed(seed))
                        diff = max(float((x - y[:, 0]).abs().max()) for x, y in zip(out, native))
                        checks.append({'panel': panel, 'production_max_abs_difference': diff})
                        assert diff < 1e-5, diff
                    if panel == 'move':
                        raw[name]['shift'].extend(f(out[0]))
                    else:
                        raw[name]['kind'].extend(kind_grid(reader, out[0], out[2]).tolist())
            print(panel, start + len(batch), '/', len(rows), flush=True)
        result[panel] = {'contexts': rows, 'raw': raw, 'summary': summarize(panel, raw)}
    return result, checks


@torch.no_grad()
def kind_grid(reader, p, v):
    x = torch.cat([p[:, :63].float().reshape(-1, p.shape[-1]), v.float().repeat_interleave(63, 0)], -1)
    return reader(x)['kind'].argmax(-1).reshape(len(p), 63)[:, S.KEEP[:63]].cpu().numpy()


def summarize(panel, raw):
    ep = np.array(raw['ep'])
    out = {}
    if panel == 'move':
        valid = np.array(raw['valid'], bool)
        real = np.array(raw['real_shift'])
        out['real'] = stats(real[valid], ep[valid])
        baseline = np.array(raw['euler_3_churn_1']['shift'])
        for alg in ALGS:
            x = np.array(raw[alg]['shift'])
            out[alg] = {'shift': stats(x[valid], ep[valid]),
                        'change_vs_production': stats((x-baseline)[valid], ep[valid])}
    else:
        real, truth = np.array(raw['real_kind']), np.array(raw['truth_kind'])
        out['real_cell_accuracy'] = float((real == truth).mean())
        out['real_count'] = {k: stats((real == j).sum(1), ep) for j,k in enumerate(G.KINDS, 1)}
        out['truth_count'] = {k: stats((truth == j).sum(1), ep) for j,k in enumerate(G.KINDS, 1)}
        base = np.array(raw['euler_3_churn_1']['kind'])
        for alg in ALGS:
            x = np.array(raw[alg]['kind'])
            out[alg] = {k: {'count': stats((x == j).sum(1), ep),
                            'change_vs_production': stats((x == j).sum(1) - (base == j).sum(1), ep)}
                        for j,k in enumerate(G.KINDS, 1)}
    return out


def main():
    p = argparse.ArgumentParser(); p.add_argument('--smoke', action='store_true'); args = p.parse_args()
    torch.set_num_threads(4)
    start = time.time()
    L = S.first_episodes(dict(np.load(S.LABELS/'s0_dev_labels.npz')), 8 if args.smoke else 150)
    grids = [d['grid'] for d in G.episode_grids(L)]
    out = {'algorithms': {k:list(v) for k,v in ALGS.items()}, 'plan_sha256': TR.file_sha256(HERE/'PLAN.md'),
           'source_sha256': TR.file_sha256(Path(__file__)), 'smoke': args.smoke, 'models': {}}
    shared = None
    target = HERE / ('smoke.json' if args.smoke else 'results.json')
    for name in ('w1_random', 'p1f_random'):
        path, _, rp = A.CONDITIONS[name]
        ck = torch.load(path, weights_only=False, map_location='cpu'); cfg = ck['cfg']
        assert cfg['edm']['sampler']['steps'] == 3 and cfg['edm']['sampler']['s_churn'] == 1
        assert cfg['edm']['sampler']['s_noise'] == 1 and cfg['edm']['sampler']['sigma_max'] == 5
        assert cfg['edm']['sampler']['s_tmin'] == 0 and cfg['edm']['sampler']['s_tmax'] >= 5
        model = M.M0(cfg).to(DEV).eval().requires_grad_(False); model.load_state_dict(ck['model']); del ck
        enc = S.encode(model, L, cfg)
        reader = S.load_reader(rp, path, DEV)
        rows = [(e, t, int(enc[e]['prev_action'][t])) for e in range(len(enc)) for t in range(8, len(enc[e]['p']))]
        rng = np.random.default_rng(610370)
        count = [rows[i] for i in rng.choice(len(rows), min(16 if args.smoke else 256, len(rows)), replace=False)]
        old = CAT.N_MAX; CAT.N_MAX = 16 if args.smoke else 128
        moves = CAT.contexts(L, enc, np.random.default_rng(610340))[0]['move']; CAT.N_MAX = old
        panels = {'counts': count, 'move': moves}
        if shared is None: shared = panels
        else: assert panels == shared
        result, checks = evaluate(model, cfg, reader, enc, L, panels, grids)
        out['models'][name] = {'checkpoint': str(path), 'sha256': TR.file_sha256(path),
                               'reader_sha256': TR.file_sha256(rp), 'panels': result, 'checks': checks}
        out['elapsed_seconds'] = time.time() - start
        target.write_text(json.dumps(out, indent=1))
        print(name, 'complete', round(out['elapsed_seconds'], 1), flush=True)
        del model, enc, reader
        torch.cuda.empty_cache()


if __name__ == '__main__': main()
