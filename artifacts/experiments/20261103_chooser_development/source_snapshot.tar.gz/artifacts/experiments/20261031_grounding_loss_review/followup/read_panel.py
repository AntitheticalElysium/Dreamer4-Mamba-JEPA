"""Frozen controlled noise panel, independent generation decomposition and joint-loop fork readings."""
import os
os.environ.setdefault('JAX_PLATFORMS','cpu')
os.environ.setdefault('OMP_NUM_THREADS','4')
import argparse
import importlib
import json
from pathlib import Path
import numpy as np
import torch
from saccade import data as D, model as M, train as TR
from saccade.eval import s1 as S

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
DEV = torch.device('cuda')
PM = importlib.import_module('artifacts.experiments.20261030_fovea_placement.placement_map')
SM = importlib.import_module('artifacts.experiments.20261031_grounding_loss_review.measure')
CAT = importlib.import_module('artifacts.experiments.20261029_generation_diagnosis.catalogue')
SHORT = importlib.import_module('artifacts.experiments.20261031_fovea_shortcut_review.evaluate')


@torch.no_grad()
def encode_row(model, cfg, L, row):
    ll = SM.single_labels(L, row['episode'], row['t'])
    rule = {int(k):tuple(v) for k,v in json.loads((PM.HERE/'map.json').read_text())['rule'].items()}
    windows = PM.window_of_state(ll, rule)
    e = S.encode(model, ll, cfg, windows=windows)[0]
    # Recompute from full precision percepts to avoid converting stored half targets into noise estimates.
    return e


@torch.no_grad()
def panel(model, cfg, name, generate):
    meta = json.loads((HERE/'panel.json').read_text())
    frames = np.load(HERE/'panel.npz')['frames']
    L = dict(np.load(S.LABELS/'s0_dev_labels.npz'))
    recs = []
    for si,row in enumerate(meta['rows']):
        # Noisy perception sensitivity itself needs no history and no stochastic generator.
        image = torch.as_tensor(frames[si], device=DEV)
        mapfix = torch.tensor([[5,4]]*8, device=DEV)
        with TR.autocast(DEV,cfg):
            pp = model.perception(image,mapfix)
        stats = {k:float(z.float()[:,:63].var(0,unbiased=False).mean()) if k == 'p' else
                    float(z.float().var(0,unbiased=False).mean()) for k,z in zip(('p','g','v'),pp.parts())}
        out = {**row, 'sensor_variance':stats}
        if generate:
            e = encode_row(model,cfg,L,row)
            t = row['t']; fix = e['fix'][t].to(DEV)[None].expand(8,-1)
            bp = e['bp'][t].float().to(DEV)[None].expand(8,-1)
            with TR.autocast(DEV,cfg):
                actual = model.perception(image,fix)
                cells = M.window(fix)
                pix = M.cell_pixels(M.crop(image,fix)).float()/127.5-1
                mt,_ = model.pixels(model.tsp.predict(bp,actual.p,actual.v,cells),actual.v,cells)
                mr,_ = model.pixels(model.tsp.reconstruct(actual.g,actual.v,cells),actual.v,cells)
                out['pixel_mse_raw_mean'] = {'tsp':float((mt.float()-pix).square().mean()),
                                             'rec':float((mr.float()-pix).square().mean())}
                out['pixel_mse'] = {'tsp':float((mt.float().clamp(-1,1)-pix).square().mean()),
                                    'rec':float((mr.float().clamp(-1,1)-pix).square().mean())}
                emb = model.belief.percept_embed(actual)
                h = model.outcome.features(bp,emb)
                r = e['reward'][t].to(DEV).expand(8)
                out['reward_nll_real'] = float(-model.outcome.reward_logp(h,r).mean())
                out['continuation_bce_real'] = float(torch.nn.functional.binary_cross_entropy_with_logits(
                    model.outcome.cont_logit(h,r).float(), (~e['terminated'][t].to(DEV)).float().expand(8)))
                gen = torch.Generator(device=DEV).manual_seed(610320+si)
                cache = model.denoiser.new_cache()
                for dt in range(t-8,t):
                    x = tuple(e[k][dt].float()[None,None].to(DEV).expand(8,*([-1]*(e[k][dt].ndim+1))) for k in ('p','g','v'))
                    pa = e['prev_action'][dt].to(DEV).expand(8,1)
                    mem = model.belief.memory(e['bp'][dt].float().to(DEV)[None].expand(8,-1))[:,None]
                    ff = e['fix'][dt].to(DEV)[None,None].expand(8,1,-1)
                    cache = M.context_pass(model.denoiser,x,pa,mem,ff,cache,cfg,gen)
                pa = e['prev_action'][t].to(DEV).expand(8,1)
                mem = model.belief.memory(bp)[:,None]; fx = fix[:,None]
                shapes = [tuple(z.shape[1:]) for z in actual.parts()]
                sampled = M.sample(model.denoiser,shapes,pa,mem,fx,cache,cfg,gen)
                target = actual.p.float()[:,:63]
                pred = sampled[0][:,0].float()[:,:63]
                tv = target.var(0,unbiased=False).mean()
                gv = pred.var(0,unbiased=False).mean()
                bias = (target.mean(0)-pred.mean(0)).square().mean()
                allpair = (target[:,None]-pred[None]).square().mean()
                assert abs(float(allpair-tv-gv-bias)) < 1e-5
                out['generation_map_decomposition'] = {k:float(v) for k,v in
                    dict(sensor_variance=tv,generated_variance=gv,mean_mismatch=bias,total_pairwise_mse=allpair).items()}
                # Reuse identical target/noise draws across checkpoints; actual noised target is visible to denoiser.
                out['denoise_map'] = {}
                for sig in (.1,1.,5.):
                    ng = torch.Generator(device=DEV).manual_seed(610330+si)
                    xs = tuple(z.float()[:,None]+sig*torch.randn(z[:,None].shape,device=DEV,generator=ng) for z in actual.parts())
                    cs,co,ci,cn = M.precondition(torch.full((8,1),sig,device=DEV),cfg['edm']['sigma_data'])
                    raw,_ = model.denoiser.step(tuple(M._bcast(ci,z)*z for z in xs),cn,pa,mem,fx,cache)
                    dd = tuple(M._bcast(cs,z)*z+M._bcast(co,z)*f.float() for z,f in zip(xs,raw))
                    clean = (dd[0][:,0,:63].float()-target).square().mean()
                    c_out = M.precondition(torch.tensor(sig,device=DEV),cfg['edm']['sigma_data'])[1]
                    out['denoise_map'][str(sig)] = dict(clean_mse=float(clean),weighted_mse=float(clean/c_out.square()))
        recs.append(out)
        (HERE/f'{name}_panel.json').write_text(json.dumps({'checkpoint_name':name,'rows':recs},indent=2))
        print(name,'panel',si+1,row['stratum'],stats['p'],flush=True)
    return recs


@torch.no_grad()
def movement(model,cfg,name):
    # Fixed input-defined successful movement contexts, same first 40 dev episodes and seed in every model.
    L = S.first_episodes(dict(np.load(S.LABELS/'s0_dev_labels.npz')),40)
    rule = {int(k):tuple(v) for k,v in json.loads((PM.HERE/'map.json').read_text())['rule'].items()}
    enc = S.encode(model,L,cfg,windows=PM.window_of_state(L,rule))
    old = CAT.N_MAX; CAT.N_MAX = 128
    rows,_,_ = CAT.contexts(L,enc,np.random.default_rng(610340))
    CAT.N_MAX = old
    o = CAT.run(model,enc,L,rows['move'],'move',{}, {},cfg,torch.Generator(device=DEV).manual_seed(610341),heun=False)
    result = dict(contexts=rows['move'],f_real=o['f_real'].tolist(),f_generated=o['f_gen'].tolist(),
                  valid=o['valid'].tolist(),row_ctx=o['row_ctx'].tolist(),
                  note='Linear real-token shift functional, not probability or independently trained semantic reader')
    (HERE/f'{name}_movement.json').write_text(json.dumps(result,indent=2))
    return result


@torch.no_grad()
def counters(model,cfg,name,action=5):
    meta = json.loads((SHORT.HERE/'branches.json').read_text())
    ids = [i for a in (0,48,96,144) for i in range(a,a+8)]
    rows = [meta['rows'][i] for i in ids]
    branches = np.load(SHORT.HERE/'branches.npz')
    ai = int(action == 0)
    actual_frames = branches['frames'][ids,ai]
    values = branches['values'][ids,ai]
    L = dict(np.load(S.LABELS/'s0_dev_labels.npz'))
    tpl = SHORT.CH.templates(L)
    enc = [encode_row(model,cfg,L,r) for r in rows]
    rep = [i for i in range(len(rows)) for _ in range(4)]
    br = [rows[i] for i in rep]
    take = lambda key,dt: torch.stack([enc[i][key][rows[i]['t']+dt] for i in rep]).to(DEV)
    gen = torch.Generator(device=DEV).manual_seed(610350)
    cache = model.denoiser.new_cache()
    branch_bp = [SHORT.predicted(model,cfg,e,r['t'],action) for e,r in zip(enc,rows)]
    bp = torch.stack([branch_bp[i] for i in rep]).to(DEV)
    if action == 5:
        old = take('bp',0).float()
        assert float(((bp-old).norm(dim=-1)/old.norm(dim=-1).clamp(min=1e-8)).max()) < .02
    with TR.autocast(DEV,cfg):
        for dt in range(-8,0):
            xx = tuple(take(k,dt).float()[:,None] for k in ('p','g','v'))
            cache = M.context_pass(model.denoiser,xx,take('prev_action',dt)[:,None],
                                   model.belief.memory(take('bp',dt).float())[:,None],take('fix',dt)[:,None],cache,cfg,gen)
        result = {}
        for gaze in ('rule','cover'):
            fix = SHORT.fixations(br,gaze)
            image = torch.as_tensor(actual_frames,device=DEV)[rep]
            real = model.perception(image,fix)
            generated = M.sample(model.denoiser,[tuple(x.shape[1:]) for x in real.parts()],
                                 torch.full((len(br),1),action,device=DEV,dtype=torch.long),model.belief.memory(bp)[:,None],fix[:,None],cache,cfg,
                                 torch.Generator(device=DEV).manual_seed(610351))
            parts = tuple(z[:,0].float() for z in generated)
            read = SHORT.pixel_read(model,cfg,tpl,parts,fix,br)
            realread = SHORT.pixel_read(model,cfg,tpl,real.parts(),fix,br)
            cells = M.window(fix)
            mt,_ = model.pixels(model.tsp.predict(bp,real.p,real.v,cells),real.v,cells)
            mr,_ = model.pixels(model.tsp.reconstruct(real.g,real.v,cells),real.v,cells)
            mg,_ = model.pixels(model.tsp.reconstruct(parts[1],parts[2],cells),parts[2],cells)
            decoded=(mg.float().clamp(-1,1)+1)*127.5
            realdecoded=(mr.float().clamp(-1,1)+1)*127.5
            pix = M.cell_pixels(M.crop(image,fix)).float()/127.5-1
            each = []
            for j,r in enumerate(br):
                slot = int((cells[j] == r['cell']).nonzero()[0])
                vals,tt=tpl[r['cell']];tt=tt.to(DEV)
                pair=torch.cdist(tt,tt);pair.fill_diagonal_(float('inf'))
                dist=torch.cdist(decoded[j,slot][None],tt)[0];ix=int(dist.argmin())
                rdist=torch.cdist(realdecoded[j,slot][None],tt)[0];rix=int(rdist.argmin())
                each.append(dict(episode=r['episode'],kind=r['kind'],group=r['group'],start=r['start'],
                                 truth=int(values[rep[j]]),
                                 generated=int(read[j]),real_decoded=int(realread[j]),
                                 generated_supported=bool(dist[ix]+1e-3 < .5*pair[ix].min()),
                                 real_supported=bool(rdist[rix]+1e-3 < .5*pair[rix].min()),
                                 generated_distance=float(dist[ix]),
                                 tsp_pixel_mse=float((mt[j,slot].float().clamp(-1,1)-pix[j,slot]).square().mean()),
                                 rec_pixel_mse=float((mr[j,slot].float().clamp(-1,1)-pix[j,slot]).square().mean())))
            result[gaze] = each
    suffix='counters' if action==5 else 'noop_counters'
    (HERE/f'{name}_{suffix}.json').write_text(json.dumps(result,indent=2))


def main():
    a = argparse.ArgumentParser(); a.add_argument('name');a.add_argument('checkpoint');a.add_argument('--generation',action='store_true');a.add_argument('--movement',action='store_true')
    a.add_argument('--cpu',action='store_true')
    a.add_argument('--paired-only',action='store_true')
    args = a.parse_args();torch.set_num_threads(4)
    global DEV
    if args.cpu:
        assert not args.generation and not args.movement
        DEV = torch.device('cpu')
    ck = torch.load(args.checkpoint,weights_only=False,map_location='cpu');cfg=ck['cfg']
    model = M.M0(cfg).to(DEV);model.load_state_dict(ck['model']);model.eval();del ck
    if args.paired_only:
        counters(model,cfg,args.name,5);counters(model,cfg,args.name,0)
        (HERE/f'{args.name}_counter_identity.json').write_text(json.dumps(dict(
            checkpoint_sha256=TR.file_sha256(args.checkpoint),script_sha256=TR.file_sha256(__file__),
            output_sha256={s:TR.file_sha256(HERE/f'{args.name}_{s}.json') for s in ('counters','noop_counters')}),indent=2))
        return
    panel(model,cfg,args.name,args.generation)
    if args.movement:
        movement(model,cfg,args.name)
        counters(model,cfg,args.name)
        counters(model,cfg,args.name,0)
        (HERE/f'{args.name}_counter_identity.json').write_text(json.dumps(dict(
            checkpoint_sha256=TR.file_sha256(args.checkpoint),script_sha256=TR.file_sha256(__file__),
            output_sha256={s:TR.file_sha256(HERE/f'{args.name}_{s}.json') for s in ('counters','noop_counters')}),indent=2))
    p = HERE/f'{args.name}_panel.json';data=json.loads(p.read_text())
    data.update(checkpoint_sha256=TR.file_sha256(args.checkpoint),script_sha256=TR.file_sha256(__file__),
                canonical_sha256={str(p.relative_to(ROOT)):TR.file_sha256(p) for p in
                    (ROOT/'saccade/model.py',ROOT/'saccade/train.py',ROOT/'saccade/eval/s1.py')})
    p.write_text(json.dumps(data,indent=2))


if __name__ == '__main__':main()
