"""Exploratory illumination sweep above the renderer's static threshold; CPU only."""
import os
os.environ.setdefault('JAX_PLATFORMS','cpu')
os.environ.setdefault('OMP_NUM_THREADS','4')
import argparse
import json
from pathlib import Path
import jax
import numpy as np
import torch
from artifacts.eda import replay as RP
from saccade import model as M, train as TR

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[3]


def prepare():
    rows=json.loads((HERE/'panel.json').read_text())['rows']
    lights=(.55,.7,.85,1.)
    _,_,_,_,render=RP.env_and_render();all_frames=[]
    for row in rows:
        st=RP.advance_to(row['shard'],row['slot'],row['t'])
        ff=[]
        for light in lights:
            a=np.asarray(render(st.replace(light_level=light,state_rng=jax.random.PRNGKey(1))))
            b=np.asarray(render(st.replace(light_level=light,state_rng=jax.random.PRNGKey(2))))
            assert np.array_equal(a,b)
            ff.append(a)
        all_frames.append(ff)
    np.savez_compressed(HERE/'lighting.npz',frames=np.stack(all_frames))
    (HERE/'lighting_meta.json').write_text(json.dumps({'lights':lights,'renderer_rng_difference':0,'rows':rows},indent=2))


@torch.no_grad()
def read(name,path):
    ck=torch.load(path,map_location='cpu',weights_only=False)
    m=M.M0(ck['cfg']);m.load_state_dict(ck['model']);m.eval()
    images=np.load(HERE/'lighting.npz')['frames'];out=[]
    for a in images:
        p=m.perception(torch.as_tensor(a),torch.tensor([[5,4]]*4))
        out.append({k:float(z[:,:63].var(0,unbiased=False).mean()) if k=='p' else
                      float(z.var(0,unbiased=False).mean()) for k,z in zip(('p','g','v'),p.parts())})
    result={'name':name,'checkpoint_sha256':TR.file_sha256(path),'rows':out,'precision':'CPU float32'}
    (HERE/f'{name}_lighting.json').write_text(json.dumps(result,indent=2))
    print(name,{k:float(np.mean([r[k] for r in out])) for k in out[0]},flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('args',nargs='*');a=p.parse_args();torch.set_num_threads(4)
    if not a.args:prepare()
    else:read(*a.args)
