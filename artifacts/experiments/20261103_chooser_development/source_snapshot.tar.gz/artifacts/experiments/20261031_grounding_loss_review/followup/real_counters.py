"""CPU check of each fork's own fovea decoder, against exact renderer glyphs."""
import importlib
import json
import sys
from pathlib import Path
import numpy as np
import torch
from saccade import model as M, train as TR
from saccade.eval import s1 as S

HERE=Path(__file__).resolve().parent
SHORT=importlib.import_module('artifacts.experiments.20261031_fovea_shortcut_review.evaluate')


@torch.no_grad()
def main(name,path):
    torch.set_num_threads(4)
    ck=torch.load(path,map_location='cpu',weights_only=False);m=M.M0(ck['cfg']);m.load_state_dict(ck['model']);m.eval()
    meta=json.loads((SHORT.HERE/'branches.json').read_text());ids=[i for a in (0,48,96,144) for i in range(a,a+8)]
    rows=[meta['rows'][i] for i in ids];br=np.load(SHORT.HERE/'branches.npz');frames=torch.as_tensor(br['frames'][ids,0]);values=br['values'][ids,0]
    L=dict(np.load(S.LABELS/'s0_dev_labels.npz'));tpl=SHORT.CH.templates(L)
    result={}
    for gaze in ('rule','cover'):
        fix=torch.tensor([r['rule_fix'] if gaze=='rule' else [6 if r['rule_fix'][0]==7 else 7,r['rule_fix'][1]] for r in rows])
        percept=m.perception(frames,fix);cells=M.window(fix)
        mu,_=m.pixels(m.tsp.reconstruct(percept.g,percept.v,cells),percept.v,cells)
        decoded=(mu.float().clamp(-1,1)+1)*127.5
        actual=M.cell_pixels(M.crop(frames,fix)).float();out=[]
        for i,r in enumerate(rows):
            slot=int((cells[i]==r['cell']).nonzero()[0]);vals,t=tpl[r['cell']]
            read=int(vals[int(torch.cdist(decoded[i,slot][None],t).argmin())])
            out.append(dict(kind=r['kind'],episode=r['episode'],truth=int(values[i]),read=read,
                            mae=float((decoded[i,slot]-actual[i,slot]).abs().mean())))
        result[gaze]=out
    (HERE/f'{name}_real_counters_cpu.json').write_text(json.dumps(result,indent=2))
    print(name,{g:{k:float(np.mean([r['read']==r['truth'] for r in rr if r['kind']==k])) for k in ('wood','drink')} for g,rr in result.items()},flush=True)


if __name__=='__main__':main(*sys.argv[1:])
