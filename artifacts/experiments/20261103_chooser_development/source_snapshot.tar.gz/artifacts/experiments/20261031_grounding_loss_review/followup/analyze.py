"""Paired scene/episode bootstrap; report all fixed endpoints, including negative results."""
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def estimate(x, groups=None):
    x = np.asarray(x,float)
    if groups is None: groups = np.arange(len(x))
    groups = np.asarray(groups); ids = np.unique(groups)
    rng = np.random.default_rng(610360)
    sums=np.array([x[groups==g].sum() for g in ids]);counts=np.array([(groups==g).sum() for g in ids])
    draws=rng.integers(len(ids),size=(2000,len(ids)))
    means=sums[draws].sum(1)/counts[draws].sum(1)
    return dict(mean=float(x.mean()),ci95=np.quantile(means,[.025,.975]).tolist(),n=len(x),clusters=len(ids))


def panel_summary(path):
    data = json.loads(path.read_text());rows=data['rows']
    out = {}
    for stratum in ('bright','dark'):
        rr = [r for r in rows if r['stratum'] == stratum]
        get = lambda fn: estimate([fn(r) for r in rr],[r['episode'] for r in rr])
        d = {f'sensor_{k}':get(lambda r,k=k:r['sensor_variance'][k]) for k in ('p','g','v')}
        if 'generation_map_decomposition' in rr[0]:
            d.update({k:get(lambda r,k=k:r['generation_map_decomposition'][k]) for k in rr[0]['generation_map_decomposition']})
            d.update({f'denoise_{s}':get(lambda r,s=s:r['denoise_map'][s]['weighted_mse']) for s in rr[0]['denoise_map']})
            d.update({f'pixel_{k}':get(lambda r,k=k:r['pixel_mse'][k]) for k in ('tsp','rec')})
            d['reward_nll_real']=get(lambda r:r['reward_nll_real'])
        out[stratum] = d
    return out


def main():
    out = {'panel':{},'movement':{},'counters':{},'fork_paired_differences':{}}
    panels = {}
    for p in sorted(HERE.glob('*_panel.json')):
        name = p.stem.removesuffix('_panel');panels[name]=json.loads(p.read_text())['rows']
        out['panel'][name] = panel_summary(p)
    for p in sorted(HERE.glob('*_movement.json')):
        name=p.stem.removesuffix('_movement');d=json.loads(p.read_text());ok=np.asarray(d['valid'],bool)
        eps=np.asarray([d['contexts'][i][0] for i in d['row_ctx']])
        out['movement'][name] = {k:estimate(np.asarray(d[k])[ok],eps[ok]) for k in ('f_real','f_generated')}
    out['movement_paired_difference']={}
    if (HERE/'MM_movement.json').exists():
        ref=json.loads((HERE/'MM_movement.json').read_text())
        for name in ('NM','MN','NN','BM','SM'):
            p=HERE/f'{name}_movement.json'
            if not p.exists():continue
            d=json.loads(p.read_text());assert d['contexts']==ref['contexts'] and d['row_ctx']==ref['row_ctx']
            ok=np.asarray(d['valid'],bool)&np.asarray(ref['valid'],bool)
            eps=np.asarray([d['contexts'][i][0] for i in d['row_ctx']])
            residual=(np.array(d['f_generated'])-np.array(d['f_real']))-(np.array(ref['f_generated'])-np.array(ref['f_real']))
            out['movement_paired_difference'][name]=estimate(residual[ok],eps[ok])
    for p in sorted(HERE.glob('*_counters.json')):
        name=p.stem.removesuffix('_counters');d=json.loads(p.read_text());o={}
        for gaze,rr in d.items():
            o[gaze]={}
            for kind in ('wood','drink'):
                rows=[r for r in rr if r['kind']==kind]
                o[gaze][kind]={}
                for k,fn in [('generated_correct',lambda r:r['generated']==r['truth']),
                             ('real_decoded_correct',lambda r:r['real_decoded']==r['truth']),
                             ('tsp_pixel_mse',lambda r:r['tsp_pixel_mse']),('rec_pixel_mse',lambda r:r['rec_pixel_mse'])]:
                    o[gaze][kind][k]=estimate([fn(r) for r in rows],[r['episode'] for r in rows])
                if 'generated_supported' in rows[0]:
                    for k,fn in [('verified_correct',lambda r:r['generated_supported'] and r['generated']==r['truth']),
                                 ('unknown',lambda r:not r['generated_supported']),
                                 ('real_supported_correct',lambda r:r['real_supported'] and r['real_decoded']==r['truth'])]:
                        o[gaze][kind][k]=estimate([fn(r) for r in rows],[r['episode'] for r in rows])
        out['counters'][name]=o
    out['noop_counters']={}
    for p in sorted(HERE.glob('*_noop_counters.json')):
        name=p.stem.removesuffix('_noop_counters');d=json.loads(p.read_text());o={}
        for gaze,rr in d.items():
            o[gaze]={}
            for kind in ('wood','drink'):
                r=[x for x in rr if x['kind']==kind]
                o[gaze][kind]={k:estimate([fn(t) for t in r],[t['episode'] for t in r]) for k,fn in
                    [('verified_false_increase',lambda t:t['generated_supported'] and t['generated']>t['start']),
                     ('unknown',lambda t:not t['generated_supported']),
                     ('real_supported_correct',lambda t:t['real_supported'] and t['real_decoded']==t['truth'])]}
        out['noop_counters'][name]=o
    if 'MM' in panels:
        for name in ('NM','MN','NN','BM','SM'):
            if name not in panels:continue
            a,b=panels[name],panels['MM'];assert [(r['episode'],r['t']) for r in a] == [(r['episode'],r['t']) for r in b]
            out['fork_paired_differences'][name]={}
            for stratum in ('bright','dark'):
                ids=[i for i,r in enumerate(a) if r['stratum']==stratum]
                fns={'sensor_p':lambda r:r['sensor_variance']['p'],
                     'generation_total':lambda r:r['generation_map_decomposition']['total_pairwise_mse'],
                     'generation_mean_mismatch':lambda r:r['generation_map_decomposition']['mean_mismatch'],
                     'denoise_5':lambda r:r['denoise_map']['5.0']['weighted_mse']}
                out['fork_paired_differences'][name][stratum]={k:estimate([fn(a[i])-fn(b[i]) for i in ids]) for k,fn in fns.items()}
    if all(n in panels for n in ('MM','NM','MN','NN')):
        ids=[i for i,r in enumerate(panels['MM']) if r['stratum']=='dark']
        z={n:np.array([panels[n][i]['sensor_variance']['p'] for i in ids]) for n in ('MM','NM','MN','NN')}
        out['factorial_noise_effects']={
            'TSP_NLL_minus_MSE':estimate((z['NM']+z['NN']-z['MM']-z['MN'])/2),
            'rec_NLL_minus_MSE':estimate((z['MN']+z['NN']-z['MM']-z['NM'])/2),
            'interaction':estimate(z['NN']-z['NM']-z['MN']+z['MM'])}
    out['training']={}
    for arm in ('MM','NM','MN','NN','BM','SM'):
        f=HERE/arm/'log.jsonl'
        if not f.exists():continue
        rr=[json.loads(x) for x in f.read_text().splitlines()]
        if not rr:continue
        out['training'][arm]={'updates':len(rr),'first_grad_norm':rr[0]['grad_norm'],
            'median_grad_norm':float(np.median([r['grad_norm'] for r in rr])),
            'median_clip_multiplier':float(np.median([r['clip_multiplier'] for r in rr])),
            'first_update_norms':rr[0]['update_norms'],'last_update_norms':rr[-1]['update_norms']}
    (HERE/'summary.json').write_text(json.dumps(out,indent=2))
    for name,d in out['panel'].items():
        print(name, {s:{k:round(v['mean'],6) for k,v in z.items()} for s,z in d.items()})
    print('MOVEMENT', {n:{k:round(v['mean'],4) for k,v in d.items()} for n,d in out['movement'].items()})
    print('COUNTERS', {n:{g:{k:round(d['generated_correct']['mean'],4) for k,d in z.items()} for g,z in d.items()} for n,d in out['counters'].items()})


if __name__=='__main__':main()
