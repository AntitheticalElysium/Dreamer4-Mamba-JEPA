"""Select input-defined attempts and recover exact DO/NOOP simulator branches; CPU only."""
import os
os.environ.setdefault('JAX_PLATFORMS', 'cpu')
os.environ.setdefault('OMP_NUM_THREADS', '4')

import hashlib
import importlib
import json
from pathlib import Path
import numpy as np
import torch
from artifacts.eda import replay as RP

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
N_EP, N_KIND, SEED = 300, 96, 2031
KINDS = {'wood': (68, 's_inv', 0, 5), 'drink': (65, 's_body', 2, 3)}
DIRS = np.array([[0, 0], [0, -1], [0, 1], [-1, 0], [1, 0]])


def sha(p):
    with open(p, 'rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def labels():
    L = dict(np.load(ROOT/'artifacts/eda/s0/s0_dev_labels.npz'))
    n = min(N_EP, len(L['ep_T']))
    ns, nt = int((L['ep_T'][:n]+1).sum()), int(L['ep_T'][:n].sum())
    return {k: v[:n] if k.startswith('ep_') else v[:ns] if k.startswith('s_') else v[:nt]
            for k, v in L.items()}


def select(L):
    rng = np.random.default_rng(SEED)
    so, ao = np.r_[0, np.cumsum(L['ep_T']+1)], np.r_[0, np.cumsum(L['ep_T'])]
    result = []
    for kind, (cell, arr, col, faced) in KINDS.items():
        pools = [[], []]
        for e in range(len(L['ep_T'])):
            for t in range(8, int(L['ep_T'][e])+1):
                g = so[e]+t-1
                d = DIRS[int(L['s_dir'][g])]
                val = int(L[arr][g, col])
                if (L['t_action'][ao[e]+t-1] == 5 and not L['s_sleep'][g]
                        and L['s_view'][g, 3+d[0], 4+d[1]] == faced and 0 <= val <= 8):
                    pools[int(val > 0)].append((e, t, val))
        for group, pool in enumerate(pools):
            rng.shuffle(pool)
            # Round-robin over episodes rather than allowing a long episode to dominate.
            by_ep = {}
            for r in pool:
                by_ep.setdefault(r[0], []).append(r)
            eps = rng.permutation(list(by_ep)).tolist()
            picked = []
            while len(picked) < N_KIND//2 and any(by_ep.values()):
                for e in eps:
                    if by_ep[e] and len(picked) < N_KIND//2:
                        picked.append(by_ep[e].pop())
            for e, t, val in picked:
                result.append({'kind': kind, 'group': 'increment' if group else 'appearance',
                               'episode': int(e), 't': int(t), 'start': val, 'cell': cell,
                               'shard': int(L['ep_shard'][e]), 'slot': int(L['ep_slot'][e])})
        print('selected', kind, len([r for r in result if r['kind'] == kind]), flush=True)
    return result


def main():
    import sys
    smoke = '--smoke' in sys.argv
    L = labels()
    rows = select(L)
    if smoke:
        rows = [next(r for r in rows if r['kind'] == k) for k in KINDS]
    _, _, _, step, frame = RP.env_and_render()
    frames, rewards, dones, values = [], [], [], []
    PM = importlib.import_module('artifacts.experiments.20261030_fovea_placement.placement_map')
    rule = {int(k): tuple(v) for k, v in json.loads((PM.HERE/'map.json').read_text())['rule'].items()}
    ctx = PM.context_ids(L)
    so = np.r_[0, np.cumsum(L['ep_T']+1)]
    for i, r in enumerate(rows):
        e, t, sh, sl = r['episode'], r['t'], r['shard'], r['slot']
        fields = RP.episode_fields(sh, sl)
        state = RP.advance_to(sh, sl, t-1)
        key = RP._slot_keys(sh, sl)[1][t-1]
        pair = [step(key, state, a) for a in (5, 0)]
        ff = np.stack([np.asarray(frame(x[1])) for x in pair])
        diff = int(np.abs(ff[0].astype(int)-fields['observations'][t].numpy().astype(int)).max())
        if diff:
            raise RuntimeError(f'replay render differs by {diff}: {r}')
        rr = np.array([float(x[2]) for x in pair], np.float32)
        if not np.isclose(rr[0], float(fields['rewards'][t-1]), atol=1e-6):
            raise RuntimeError('recorded reward differs')
        vv = [int(x[1].inventory.wood) if r['kind']=='wood' else int(x[1].player_drink) for x in pair]
        r['rule_fix'] = list(rule[int(ctx[so[e]+t-1])])
        r['replay_max_pixel_difference'] = diff
        frames.append(ff); rewards.append(rr); dones.append([bool(x[3]) for x in pair]); values.append(vv)
        if i % 16 == 0 or i == len(rows)-1:
            print('replayed', i+1, '/', len(rows), 'values', vv, flush=True)
    stem = 'smoke_branches' if smoke else 'branches'
    np.savez_compressed(HERE/f'{stem}.npz', frames=np.stack(frames), reward=np.stack(rewards),
                        terminated=np.asarray(dones), values=np.asarray(values))
    source = [Path(__file__), ROOT/'artifacts/eda/replay.py', PM.HERE/'placement_map.py',
              PM.HERE/'map.json', ROOT/'saccade/model.py', ROOT/'saccade/train.py', ROOT/'saccade/eval/s1.py']
    (HERE/f'{stem}.json').write_text(json.dumps({'rows': rows, 'episodes_limit': N_EP, 'seed': SEED,
               'source_sha256': {str(p.relative_to(ROOT)): sha(p) for p in source},
               'branches_sha256': sha(HERE/f'{stem}.npz')}, indent=2))


if __name__ == '__main__':
    main()
