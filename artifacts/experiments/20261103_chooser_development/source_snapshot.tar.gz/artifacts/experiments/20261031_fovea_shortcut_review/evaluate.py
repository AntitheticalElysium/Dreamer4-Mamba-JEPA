"""Paired, valid viewing/action interventions on frozen P1 and P1-F. See PLAN.md."""
import os
os.environ.setdefault('JAX_PLATFORMS', 'cpu')
os.environ.setdefault('OMP_NUM_THREADS', '4')
import importlib
import json
import sys
from pathlib import Path
import numpy as np
import torch
from saccade import model as M, train as TR
from saccade.eval import s1 as S

PRE = importlib.import_module('artifacts.experiments.20261031_fovea_shortcut_review.prepare')
PM = importlib.import_module('artifacts.experiments.20261030_fovea_placement.placement_map')
CH = importlib.import_module('artifacts.experiments.20261030_decoder_diagnosis.checks')
HERE, ROOT, DEV = PRE.HERE, PRE.ROOT, torch.device('cuda')
WORLDS = {'base': ROOT/'artifacts/saccade_m0/p1_world1/ckpt_10.pt',
          'p1f': ROOT/'artifacts/experiments/20261030_p1_guided/run/ckpt_10.pt'}
READERS = ROOT/'artifacts/experiments/20261030_p1_guided/readings/eval_m05'
K, BATCH, P = 4, 24, 8


@torch.no_grad()
def predicted(model, cfg, ep, t, action):
    Pe = M.Percept(*(ep[k][:t].float()[None].to(DEV) for k in ('p', 'g', 'v')),
                   ep['fix'][:t][None].to(DEV))
    aa = ep['action'][:t].clone(); aa[-1] = action
    with TR.autocast(DEV, cfg):
        x = model.belief.tokens(model.belief.percept_embed(Pe), ep['reward'][:t][None].to(DEV),
                               ep['terminated'][:t][None].to(DEV), aa[None].to(DEV))
        y, _ = model.belief(x, model.belief.initial(1, DEV))
    return y[0, -1].float().cpu()


def fixations(rows, name):
    if name == 'rule':
        return torch.tensor([r['rule_fix'] for r in rows], device=DEV)
    if name == 'cover':
        # Other valid crop; keeps the exact entire counter cell in view.
        return torch.tensor([[6 if r['rule_fix'][0] == 7 else 7, r['rule_fix'][1]] for r in rows], device=DEV)
    return torch.tensor([[3, 4]]*len(rows), device=DEV)


@torch.no_grad()
def native(model, cfg, parts, fix, bp, reward=None, gen=None):
    with TR.autocast(DEV, cfg):
        h = model.outcome.features(bp, model.belief.percept_embed(M.Percept(*parts, fix))).float()
        lp = model.outcome.bin_logp(h)
        r = model.outcome.sample_reward(h, gen) if reward is None else reward
        term = 1-torch.sigmoid(model.outcome.cont_logit(h, r).float())
    p, v = lp.exp(), model.outcome.bin_value
    out = {'event_p': (p*(v > .5)).sum(-1), 'expected_reward': (p*v).sum(-1), 'term_p': term}
    if reward is not None:
        out['true_reward_nll'] = -lp.gather(-1, model.outcome.bin_of(reward)[:, None])[:, 0]
    return {k: x.float().cpu().numpy() for k, x in out.items()}


def read_counter(readers, rows, periphery):
    read, known = [], []
    for r, p in zip(rows, periphery):
        rd = readers['p'][r['kind']]
        assert rd['qualified']
        keys = sorted(rd['means'])
        mu = torch.stack([rd['means'][k].float() for k in keys])
        tok = p[r['cell']].float().cpu()
        val = keys[int((mu-tok).norm(dim=-1).argmin())]
        support = rd['support'].get((0, int(val)))
        ok = support is not None and float((tok-support[0]).norm()) <= support[1]
        read.append(val); known.append(ok)
    return np.asarray(read), np.asarray(known)


@torch.no_grad()
def pixel_read(model, cfg, tpl, parts, fix, rows):
    cells = M.window(fix)
    with TR.autocast(DEV, cfg):
        mean, _ = model.pixels(model.tsp.reconstruct(parts[1], parts[2], cells), parts[2], cells)
    decoded = (mean.float().clamp(-1, 1)+1)*127.5
    out = []
    for i, r in enumerate(rows):
        slots = (cells[i] == r['cell']).nonzero()
        if not len(slots):
            out.append(-1)
        else:
            vals, templates = tpl[r['cell']]
            j = int(torch.cdist(decoded[i, slots[0, 0]][None], templates.to(DEV)).argmin())
            out.append(int(vals[j]))
    return np.asarray(out)


@torch.no_grad()
def main():
    smoke = '--smoke' in sys.argv
    torch.set_num_threads(4)
    stem = 'smoke_branches' if smoke else 'branches'
    meta = json.loads((HERE/f'{stem}.json').read_text())
    assert PRE.sha(HERE/f'{stem}.npz') == meta['branches_sha256']
    branches = np.load(HERE/f'{stem}.npz')
    rows, L = meta['rows'], PRE.labels()
    if smoke:
        L = S.first_episodes(L, max(r['episode'] for r in rows)+1)
    tpl = CH.templates(L)
    rule = {int(k): tuple(v) for k,v in json.loads((PM.HERE/'map.json').read_text())['rule'].items()}
    records, checks = [], {}
    def save():
        if records:
            np.savez_compressed(HERE/('smoke_samples.npz' if smoke else 'samples.npz'),
                                **{k: np.concatenate([z[k] for z in records]) for k in records[0]})
        (HERE/('smoke_checks.json' if smoke else 'checks.json')).write_text(json.dumps(checks, indent=2))
    for world, path in WORLDS.items():
        ck = torch.load(path, map_location='cpu', weights_only=False)
        cfg = ck['cfg']; model = M.M0(cfg).to(DEV); model.load_state_dict(ck['model']); model.eval()
        rd = torch.load(READERS/f'{world}_readers.pt', map_location='cpu', weights_only=False)
        assert rd['checkpoint_sha256'] == PRE.sha(path)
        readers = rd['readers']
        checks[world] = {'checkpoint': str(path), 'checkpoint_sha256': rd['checkpoint_sha256'],
                         'reader_sha256': PRE.sha(READERS/f'{world}_readers.pt'), 'replay_fidelity': []}
        del ck
        for history in ('guided', 'random'):
            print('encoding', world, history, flush=True)
            enc = S.encode(model, L, cfg, windows=PM.window_of_state(L, rule) if history=='guided' else None)
            pred = []
            for r in rows:
                ep = enc[r['episode']]
                vals = [predicted(model,cfg,ep,r['t'],a) for a in (5,0)]
                old = ep['bp'][r['t']].float()
                rel = float((vals[0]-old).norm()/old.norm().clamp(min=1e-8))
                checks[world]['replay_fidelity'].append({'history': history, 'episode': r['episode'],
                           't': r['t'], 'max_abs': float((vals[0]-old).abs().max()), 'relative_l2': rel})
                if rel > .02:
                    save(); raise RuntimeError(f'belief replay differs: {rel}')
                pred.append(torch.stack(vals))
            pred = torch.stack(pred)
            print('beliefs ready', world, history, 'max relative',
                  max(z['relative_l2'] for z in checks[world]['replay_fidelity']), flush=True)
            for b0 in range(0, len(rows), BATCH):
                ids = np.arange(b0,min(len(rows),b0+BATCH)); br = [rows[i] for i in ids]
                cache = model.denoiser.new_cache()
                gen = torch.Generator(device=DEV).manual_seed(9031+b0)
                take = lambda k,dt: torch.stack([enc[r['episode']][k][r['t']+dt].float() for r in br]).repeat_interleave(K,0).to(DEV)
                with TR.autocast(DEV,cfg):
                    for dt in range(-P,0):
                        cache = M.context_pass(model.denoiser,tuple(take(k,dt)[:,None] for k in ('p','g','v')),
                                   take('prev_action',dt).long()[:,None],model.belief.memory(take('bp',dt))[:,None],
                                   take('fix',dt).long()[:,None],cache,cfg,gen)
                rng_state = gen.get_state()
                rr = [r for r in br for _ in range(K)]
                for ai, action in enumerate((5,0)):
                    bp = pred[ids,ai].repeat_interleave(K,0).to(DEV)
                    frames = torch.as_tensor(branches['frames'][ids,ai],device=DEV).repeat_interleave(K,0)
                    truth_r = torch.as_tensor(branches['reward'][ids,ai],device=DEV).repeat_interleave(K,0)
                    for fixation in ('rule','cover','map'):
                        fix = fixations(rr,fixation)
                        for r,f in zip(rr,fix.tolist()):
                            covers = abs(f[0]-r['cell']//9)<=1 and abs(f[1]-r['cell']%9)<=1
                            assert covers == (fixation != 'map')
                        gen.set_state(rng_state)
                        with TR.autocast(DEV,cfg):
                            parts = tuple(x[:,0].float() for x in M.sample(model.denoiser,[(81,16),(9,64),(8,)],
                                torch.full((len(rr),1),action,device=DEV,dtype=torch.long),
                                model.belief.memory(bp)[:,None],fix[:,None],cache,cfg,gen))
                            real = model.perception(frames,fix)
                        # Invariant sensor: full-resolution frame and periphery do not depend on fixation.
                        if fixation == 'rule': reference_p = real.p.clone()
                        else: assert torch.equal(real.p,reference_p)
                        out = {'context': np.repeat(ids,K), 'draw': np.tile(np.arange(K),len(ids)),
                               'world': np.full(len(rr),world), 'history': np.full(len(rr),history),
                               'action': np.full(len(rr),action), 'fixation': np.full(len(rr),fixation),
                               'truth_value': np.repeat(branches['values'][ids,ai],K),
                               'truth_reward': truth_r.cpu().numpy(),
                               'truth_term': np.repeat(branches['terminated'][ids,ai],K)}
                        val, known = read_counter(readers,rr,parts[0])
                        rv, rk = read_counter(readers,rr,real.p)
                        out.update(read_value=val,read_known=known,real_read_value=rv,real_read_known=rk,
                                   pixel_value=pixel_read(model,cfg,tpl,parts,fix,rr))
                        out.update({'gen_'+k:v for k,v in native(model,cfg,parts,fix,bp,gen=gen).items()})
                        out.update({'real_'+k:v for k,v in native(model,cfg,real.parts(),fix,bp,reward=truth_r).items()})
                        records.append(out)
                print('evaluated',world,history,b0+len(ids),'/',len(rows),flush=True)
                save()
            del enc
        del model
        torch.cuda.empty_cache()
    checks['sources_sha256'] = {str(p.relative_to(ROOT)): PRE.sha(p) for p in [Path(__file__), HERE/'prepare.py',
             HERE/'PLAN.md', ROOT/'saccade/model.py',ROOT/'saccade/train.py',ROOT/'saccade/eval/s1.py']}
    checks['peak_cuda_allocated_gib'] = torch.cuda.max_memory_allocated()/2**30
    save()
    print('done',flush=True)


if __name__ == '__main__':
    main()
